<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Shooper</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">      
		<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">		
		<link href="themes/css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="themes/css/flexslider.css" rel="stylesheet"/>
		<link href="themes/css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="themes/js/jquery-1.7.2.min.js"></script>
		<script src="themes/js/script.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>				
		<script src="themes/js/superfish.js"></script>	
		<script src="themes/js/jquery.scrolltotop.js"></script>
		
		
		<!--[if lt IE 9]>			
			<script src="http://php5shim.googlecode.com/svn/trunk/php5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
    <body>		
		<div id="top-bar" class="container">
			<div class="row">
				<div class="span4">
					<form method="POST" class="search_form">
						<!--input type="text" class="input-block-level search-query" Placeholder="eg. T-sirt"-->
					</form>
				</div>
				<div class="span8">
					<div class="account pull-right">
						<ul class="user-menu">				
							<!--li><a href="cart.php">votre carte</a></li-->
											
							<li><a href="register.php">Mon compte</a></li>				
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="index.php" class="logo pull-left"><img src="themes/images/logo.png" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
																						
							<li><a href="./products.php">Vêtements</a>	</li>			
							
																	
									<li><a href="./accessoires.php">Accessoires</a></li>	
									<li><a href="./contact.php">Contact</a></li>
									
								
														
							
						</ul>
					</nav>
				</div>
			</section>							
			<section class="google_map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2894.8410574676504!2d-1.5595667848403585!3d43.4847872791274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd516ad9abb3de0b%3A0xa765611191f80d66!2s23+Avenue+Edouard+VII%2C+64200+Biarritz!5e0!3m2!1sfr!2sfr!4v1517488555790" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				<!--iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=74%2F6+Nguy%E1%BB%85n+V%C4%83n+Tho%E1%BA%A1i,+S%C6%A1n+Tr%C3%A0,+%C4%90%C3%A0+N%E1%BA%B5ng,+Vi%E1%BB%87t+Nam&amp;aq=0&amp;oq=74%2F6+Nguyen+Van+Thoai+Da+Nang,+Viet+Nam&amp;sll=37.0625,-95.677068&amp;sspn=41.546728,79.013672&amp;ie=UTF8&amp;hq=&amp;hnear=74+Nguy%E1%BB%85n+V%C4%83n+Tho%E1%BA%A1i,+Ng%C5%A9+H%C3%A0nh+S%C6%A1n,+Da+Nang,+Vietnam&amp;t=m&amp;ll=16.064537,108.24151&amp;spn=0.032992,0.039396&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe-->
			</section>
			<section class="header_text sub">
			<!--img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" -->
				<h4><span>Contactez-nous</span></h4>
			</section>
			<section class="main-content">				
				<div class="row">				
					<div class="span5">
						<div>
							<h5>Adresse</h5>
							<p><strong>Telephone:</strong>&nbsp;(+33) 0615024300<br>
							
							<strong>Email:</strong>&nbsp;<a href="#">shooper@yahoo.fr</a>								
							</p>
							<br/>
							
						</div>
					</div>
					<div class="span7">
						
						<form method="post" action="api.php?formulaire=contact" name="myForm"  onsubmit="return validercontact ();">
							<fieldset>
								<div class="clearfix">
									<label for="name"><span>Nom:</span></label>
									<div class="input">
										<input tabindex="1" size="18" id="name" name="nom"  type="text" value="" class="input-xlarge" placeholder="Name" required >
									</div>
								</div>
								
								<div class="clearfix">
									<label for="email"><span>Email:</span></label>
									<div class="input">
										<input tabindex="2" size="25" id="email" name="email" type="email" value="" class="input-xlarge" placeholder="Email Address" required>
									</div>
								</div>
								
								<div class="clearfix">
									<label for="message"><span>Message:</span></label>
									<div class="input">
										<textarea tabindex="3" class="input-xlarge" id="message" name="contenu" rows="7" placeholder="Message"  required></textarea>
									</div>
								</div>
								
								<div class="actions" >
									<button tabindex="3" type="submit" class="btn btn-inverse">Envoyer votre message</button><script> function aufeu() { 
	alert('Message envoyé');}</script> 
								</div>
							</fieldset>
						</form>
					</div>				
				</div>
			</section>			
			<section id="footer-bar">
				<div class="row">
					
					
									
				</div>	
			</section>
			<section id="copyright">
				<span><center>Copyright 2017   All right reserved.</center></span>
			</section>
		</div>
		<script src="themes/js/common.js"></script>		
    </body>
</php>