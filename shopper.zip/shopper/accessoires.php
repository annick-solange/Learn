<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Shooper</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">      
		<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">		
		<link href="themes/css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="themes/css/flexslider.css" rel="stylesheet"/>
		<link href="themes/css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="themes/js/jquery-1.7.2.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>				
		<script src="themes/js/superfish.js"></script>	
		<script src="themes/js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://php5shim.googlecode.com/svn/trunk/php5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
    <body>		
		<div id="top-bar" class="container">
			<div class="row">
				<div class="span4">
					<form method="POST" class="search_form">
						<!--input type="text" class="input-block-level search-query" Placeholder="eg. T-sirt"-->
					</form>
				</div>
				<div class="span8">
					<div class="account pull-right">
						<ul class="user-menu">				
							<!--li><a href="cart.php">votre carte</a></li-->
									
							<li><a href="register.php">Mon compte</a></li>	
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="index.php" class="logo pull-left"><img src="themes/images/logo.png" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="./products.php">Vêtements</a>	
								
							</li>															
										
							
																	
									<li><a href="./accessoires.php">Accessoires</a></li>
									<li><a href="./contact.php">Contact</a></li>
									
								
														
							
						</ul>
					</nav>
				</div>
			</section>	
			<section class="header_text sub">
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				
			</section>
			
			<section class="main-content">
				
				<div class="row">	
					
					<div class="span9">	
						
						<ul class="thumbnails listing-products">
						<?php     
										 include 'connect.php';
										// $donnes=$bdd->query("SELECT * FROM articles");
										//$reponses=$donnees->fetchColumn();
										 $sql = 'SELECT Nom_Image, Libelle_Article,Details_Article, Prix_Article, c.Id_Categorie FROM image i,articles a, categorie_articles c where c.Id_Categorie= a.Id_Categorie And a.Id_Article=i.Id_Article and a.Id_Categorie=10' ;
									$req = $bdd->query($sql);
									while($data = $req->fetch()){  
									?>  
									
							<li class="span3">
							<div class="product-box">
							<span class="sale_tag"></span>	
									 
										<img alt="" src="themes/images/ladies/<?php echo $data['Nom_Image']; ?>"/><p class="price"><?php echo $data['Libelle_Article']?></p><?php echo $data['Prix_Article'] ?>€
									 <p><a href="register.php"><input tabindex="3" class="btn btn-inverse large" type ="submit" value="commander" /> </a><p><br/>

								
								
								</div>	
								
								<?php
								} 
             
								?>
							</li>       
							
						</ul>								
						<hr>
						
					</div>
					<div class="span3 col">
					</div>
				</div>
			</section>
			<section id="footer-bar">
				<div class="row">
					
					
									
				</div>	
			</section>
			<section id="copyright">
				<span><center>Copyright 2017   All right reserved.</center></span>
			</section>
		</div>
		<script src="themes/js/common.js"></script>	
    </body>
</html>