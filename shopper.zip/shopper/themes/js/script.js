function validercontact ( )
{
    
    var nom = document.forms["myForm"]["nom"].value;
    if (nom == "") {
        alert("veuillez renseigner le nom");
        return false;
    }
	
	var email = document.forms["myForm"]["email"].value;
    if (email == "") {
        alert("veuillez renseigner le mail");
        return false;
    }
	
	var contenu = document.forms["myForm"]["contenu"].value;
    if (contenu == "") {
        alert("veuillez renseigner votre message");
        return false;
    }
}
 function login ( )
{
    
    var login = document.forms["myForm"]["login"].value;
    if (login == "") {
        alert("veuillez renseigner votre login");
        return false;
    }
	
	var mdp = document.forms["myForm"]["password"].value;
    if (mdp == "") {
        alert("veuillez renseigner le mot de passe");
        return false;
    }
	
	
}

function minLength(element, min){
    value = element.value;
    min = parseInt(min);
    if(value.length > min){
        element.value = value.substr(0, min);
    }
}

