<?php

/**
 * Verifie si le panier existe, le créé sinon
 * @return booleen
 */
function creationPanier(){
   if (!isset($_SESSION['panier'])){
      $_SESSION['panier']=array();
      $_SESSION['panier']['Libelle_Article'] = array();
      $_SESSION['panier']['qte_Article'] = array();
      $_SESSION['panier']['Prix_Article'] = array();
      $_SESSION['panier']['verrou'] = false;
   }
   return true;
}


/**
 * Ajoute un article dans le panier
 * @param string $libelle_Article
 * @param int $qte_Article
 * @param float $prix_Article
 * @return void
 */
function ajouterArticle($libelle_Article,$qte_Article,$prix_Article){

   //Si le panier existe
   if (creationPanier() && !isVerrouille())
   {
      //Si le _Article existe déjà on ajoute seulement la quantité
      $position_Article = array_search($libelle_Article,  $_SESSION['panier']['libelle_Article']);

      if ($position_Article !== false)
      {
         $_SESSION['panier']['qte_Article'][$position_Article] += $qte_Article ;
      }
      else
      {
         //Sinon on ajoute le _Article
         array_push( $_SESSION['panier']['Libelle_Article'],$libelle_Article);
         array_push( $_SESSION['panier']['qte_Article'],$qte_Article);
         array_push( $_SESSION['panier']['prix_Article'],$prix_Article);
      }
   }
   else
   echo "Un problème est survenu veuillez contacter l'administrateur du site.";
}



/**
 * Modifie la quantité d'un article
 * @param $libelle_Article
 * @param $qte_Article
 * @return void
 */
function modifierQTeArticle($libelle_Article,$qte_Article){
   //Si le panier éxiste
   if (creationPanier() && !isVerrouille())
   {
      //Si la quantité est positive on modifie sinon on supprime l'article
      if ($qte_Article > 0)
      {
         //Recharche du _Article dans le panier
         $position_Article = array_search($libelle_Article,  $_SESSION['panier']['libelle_Article']);

         if ($position_Article !== false)
         {
            $_SESSION['panier']['qte_Article'][$position_Article] = $qte_Article ;
         }
      }
      else
      supprimerArticle($libelle_Article);
   }
   else
   echo "Un problème est survenu veuillez contacter l'administrateur du site.";
}

/**
 * Supprime un article du panier
 * @param $libelle_Article
 * @return unknown_type
 */
function supprimerArticle($libelle_Article){
   //Si le panier existe
   if (creationPanier() && !isVerrouille())
   {
      //Nous allons passer par un panier temporaire
      $tmp=array();
      $tmp['Libelle_Article'] = array();
      $tmp['qte_Article'] = array();
      $tmp['Prix_Article'] = array();
      $tmp['verrou'] = $_SESSION['panier']['verrou'];

      for($i = 0; $i < count($_SESSION['panier']['Libelle_Article']); $i++)
      {
         if ($_SESSION['panier']['Libelle_Article'][$i] !== $libelle_Article)
         {
            array_push( $tmp['Libelle_Article'],$_SESSION['panier']['Libelle_Article'][$i]);
            array_push( $tmp['qte_Article'],$_SESSION['panier']['qte_Article'][$i]);
            array_push( $tmp['Prix_Article'],$_SESSION['panier']['Prix_Article'][$i]);
         }

      }
      //On remplace le panier en session par notre panier temporaire à jour
      $_SESSION['panier'] =  $tmp;
      //On efface notre panier temporaire
      unset($tmp);
   }
   else
   echo "Un problème est survenu veuillez contacter l'administrateur du site.";
}


/**
 * Montant total du panier
 * @return int
 */
function MontantGlobal(){
   $total=0;
   for($i = 0; $i < count($_SESSION['panier']['Libelle_Article']); $i++)
   {
      $total += $_SESSION['panier']['qte_Article'][$i] * $_SESSION['panier']['Prix_Article'][$i];
   }
   return $total;
}


/**
 * Fonction de suppression du panier
 * @return void
 */
function supprimePanier(){
   unset($_SESSION['panier']);
}

/**
 * Permet de savoir si le panier est verrouillé
 * @return booleen
 */
function isVerrouille(){
   if (isset($_SESSION['panier']) && $_SESSION['panier']['verrou'])
   return true;
   else
   return false;
}

/**
 * Compte le nombre d'articles différents dans le panier
 * @return int
 */
function compterArticles()
{
   if (isset($_SESSION['panier']))
   return count($_SESSION['panier']['Libelle_Article']);
   else
   return 0;

}

?>