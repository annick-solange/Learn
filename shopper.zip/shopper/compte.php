<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Shooper</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">      
		<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
		
		<link href="themes/css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="themes/css/flexslider.css" rel="stylesheet"/>
		<link href="themes/css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="themes/js/jquery-1.7.2.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>				
		<script src="themes/js/superfish.js"></script>	
		<script src="themes/js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://php5shim.googlecode.com/svn/trunk/php5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
    <body>		
		<div id="top-bar" class="container">
			<div class="row">
				<div class="span4">
					<form method="POST" class="search_form">
						<!--input type="text" class="input-block-level search-query" Placeholder="eg. T-sirt"-->
					</form>
				</div>
				<form method="POST" class="search_form" action="api.php?formulaire=login">
						
					
				<div class="span8">
					<div class="account pull-right">
						<ul class="user-menu">				
							
							
							<?php
							
							session_start();
							echo ('<strong><li><a href="#">'.$_SESSION['login'].'</a></li></strong>');
							?>
							
							
							
						</ul>
					</div>
				
				</div>
				</form>
			</div>
		</div>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="#" class="logo pull-left"><img src="themes/images/logo.png" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="./products_c.php">Vêtements</a>				
								
							</li>															
										
							
																	
									<li><a href="./accessoires_c.php">Accessoires</a></li>
									<li><a href="./contact_c.php">Contact</a></li>	
									
								
														
							
						</ul>
					</nav>
				</div>
			</section>
			<section  class="homepage-slider" id="home-slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<img src="themes/images/carousel/b2.jpg" alt="" />
						</li>
						<li>
							<img src="themes/images/carousel/banner-2.jpg" alt="" />
							<div class="intro">
							</div>
						</li>
					</ul>
				</div>			
			</section>
			
			<section class="main-content">
				<div class="row">
					<div class="span12">													
						<div class="row">
							<div class="span12">
								<h4 class="title">
									<span class="pull-left"><span class="text"><span class="line">Nos <strong>Catalogues</strong></span></span></span>
									<span class="pull-right">
										<a class="left button" href="#myCarousel" data-slide="prev"></a><a class="right button" href="#myCarousel" data-slide="next"></a>
									</span>
								</h4>
								<div id="myCarousel" class="myCarousel carousel slide">
									<div class="carousel-inner">
										<div class="active item">
										<ul class="thumbnails listing-products">
						<?php     
										 include 'connect.php';
										 
										 
										 $sql = 'SELECT Nom_Image, Libelle_Article,Details_Article,a.Id_Article,Prix_Article FROM image i,articles a where a.Id_Article=i.Id_Article';
									$req = $bdd->query($sql);
									while($data = $req->fetch()){  
									$_SESSION['Nom_Image'] = $data['Nom_Image'];
									?>  
							<li class="span3">
							<div class="product-box">
							<span class="sale_tag"></span>	
									 
							 <img alt="" src="themes/images/ladies/<?php echo $data['Nom_Image']; ?>"/><p class="price"><?php echo $data['Libelle_Article']?></p><?php echo $data['Prix_Article'] ?>€
									  <p><a href="product_detail_c.php?id=<?php echo $data['Id_Article'] ?>&nom=<?php echo $data['Nom_Image'] ?>&detail=<?php echo $data['Details_Article'] ?>&prix=<?php echo $data['Prix_Article'] ?>"><input tabindex="3" class="btn btn-inverse large" type ="submit" value="commander" /> </a><p><br/>
								
								</div>	
								
							<?php
								} 
             
								?>
							</li>       
							
						
						<br/>
						
					</div>					
				</div>	
			</section>
			<section id="copyright">
				<span><center>Copyright 2017   All right reserved.</center></span>
			</section>
		</div>
		<script src="themes/js/common.js"></script>
		<script src="themes/js/jquery.flexslider-min.js"></script>
		<script type="text/javascript">
			$(function() {
				$(document).ready(function() {
					$('.flexslider').flexslider({
						animation: "fade",
						slideshowSpeed: 4000,
						animationSpeed: 600,
						controlNav: false,
						directionNav: true,
						controlsContainer: ".flex-container" // the container that holds the flexslider
					});
				});
			});
		</script>
    </body>
</html>