<?php

include ('connect.php');
session_start();
$formulaire = $_GET['formulaire'];
switch ($formulaire) {
case "contact" :
$nom=$_POST["nom"] ;
	$email=$_POST["email"] ;
	$contenu=$_POST["contenu"] ;
	$req=$bdd->prepare("INSERT INTO message(nom, email, contenu) VALUES (?,?,?)");
	$req->execute(array($_POST["nom"], $_POST["email"],$_POST["contenu"]));
	header("Location: index.php");
break;

case "login" :

	$login=$_POST["login"];
	$password=$_POST["password"];
	//$nom=$_POST["nom"];
	$query=$bdd->query("SELECT * FROM client WHERE Login_Client='$login' AND MotPasse_Client='$password'");
	$donnees=$query->fetchAll();
if (count($donnees)==1) {
    
    $_SESSION['login'] = $_POST['login']; 
    $_SESSION['password'] = $_POST['password'];
	

    header("Location: compte.php");
} else {

    header("Location: register.php");
}
break;
	case "inscription" :
	$nom=$_POST["nom"] ;
	$prenom=$_POST["prenom"] ;
	$email=$_POST["email"] ;
	$login=$_POST["login"] ;
	$password=$_POST["password"] ;
	$telephone=$_POST["telephone"];
	$departement=$_POST["departement"];
	$data=$bdd->query("SELECT Id_Departement FROM departement WHERE Nom_Departement='$departement'");
	$reponses=$data->fetchColumn();
	
	$sql =( 'SELECT Login_Client, Mail_Client FROM client WHERE Login_Client= ? OR Mail_Client = ?');
	$donnes=$bdd->prepare($sql);
	$donnes->execute(array($_POST['login'], $_POST['email']));
	$nb= $donnes -> rowCount($sql);
	
	if ($nb == 0) {
	$req1=$bdd->prepare("INSERT INTO client(Nom_Client,Prenom_Client,Mail_Client,Login_Client,MotPasse_Client,Telephone_Client,	Id_Departement) VALUES (?,?,?,?,?,?,?)");
$req1->execute(array($_POST["nom"], $_POST["prenom"],$_POST["email"],$_POST["login"],$_POST["password"], $_POST["telephone"],$reponses));

	
	header("Location: register_c.php");
	} 
	else {
		
	echo'<script language="javascript">alert("Login ou mail déja existant");</script>';
}
	
	break;
	
}
