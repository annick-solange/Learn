		<?php
					include 'connect.php';
					$date = date("Y-m-d H:i:s");
	//$quantite=$_GET["quantite"];
	$client=$_GET['client'];
	 $variable=$_GET['id'];
	
	$quer=$bdd->query("SELECT Id_Client FROM client WHERE Login_Client='$client' ");
	$rep=$quer->fetchColumn();
	echo $rep;
	$sql = $bdd->prepare('SELECT * FROM articles WHERE Id_Article=?');
	$sql->execute(array($variable));
	$data = $sql->fetchColumn();
	//var_dump($data);
	
	//$req3=$bdd->query("SELECT Id_Article FROM articles WHERE Id_Article='$article' ");
	//$answer=$req3->fetchColumn();
	
	
	$var=$bdd->prepare("INSERT INTO commande(quantite_Commande,Date_Commande,Id_Article,Id_Client)VALUES(?,?,?,?)");
	$var->execute(array(2,$date,$data,$rep));
	header("Location:compte.php ");
	

?>