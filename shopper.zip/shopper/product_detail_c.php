
<!DOCTYPE php>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Shooper</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		
		<!-- bootstrap -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">      
		<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">		
		<link href="themes/css/bootstrappage.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="themes/css/main.css" rel="stylesheet"/>
		<link href="themes/css/jquery.fancybox.css" rel="stylesheet"/>
				
		<!-- scripts -->
		<script src="themes/js/jquery-1.7.2.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>				
		<script src="themes/js/superfish.js"></script>	
		<script src="themes/js/jquery.scrolltotop.js"></script>
		<script src="themes/js/jquery.fancybox.js"></script>
		<script src="themes/js/script.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://php5shim.googlecode.com/svn/trunk/php5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
    <body>		
		<div id="top-bar" class="container">
			<div class="row">
				<div class="span4">
					<form method="POST" class="search_form">
					</form>
				</div>
				<div class="span8">
					<div class="account pull-right">
						<ul class="user-menu">				
							<?php
							
							session_start();
							echo ('<strong><li><a href="#">'.$_SESSION['login'].'</a></li></strong>');
							?>	
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="index.php" class="logo pull-left"><img src="themes/images/logo.png" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="./products_c.php">Vêtements</a>						
								
							</li>															
								
							
																	
									<li><a href="./accessoires_c.php">Accessoires</a></li>
									<li><a href="./contact_c.php">Contact</a></li>
									
								
														
							
						</ul>
					</nav>
				</div>
			</section>
			<section class="header_text sub">
			<img class="pageBanner" src="themes/images/pageBanner.png" alt="New products" >
				<h4><span></span></h4>
			</section>
			<section class="main-content">				
				<div class="row">						
					<div class="span9">
						<div class="row">
							<div class="span4">
							<?php     
										 include 'connect.php';
										 $variable=$_GET['id'];
										 $nom=$_GET['nom'];
										 $details=$_GET['detail'];
										 
										
										  $prix=$_GET['prix'];
										   //echo($prix);
										 ?>
										 
										<img alt="" src="themes/images/ladies/<?php echo $nom  ; ?>" />			 
							<div class="span5">
								<address>
									<h4><strong>Description:</strong></h4> <span> <?php echo $details  ; ?></span><br>
																	
								</address>									
								<h4><strong>Prix:</strong> <?php echo $prix  ; ?>€</h4>
							</div>
							<div class="span5">
								
									
									<p>&nbsp;</p>
									
									<a href ="panier.php?id=<?php echo $variable ?>&nom=<?php echo $nom ?>&detail=<?php echo $details ?>&prix=<?php echo $prix ?>"/><p><input  class="btn btn-inverse" type="submit" value="Acheter"/></p>
								
								<!--?php echo '<a href="api.php?id=.. '; ?-->
							</div>
							
							
						</div>
					</div>
					
			</section>	
			<section id="footer-bar">
				<div class="row">
				<div class="span3 col">
						
						
					</div>	
					
									
				</div>	
			</section>
			<section id="copyright">
			
			
				<span><center>Copyright 2017   All right reserved.</center></span>
			</section>
			<br>
		</div>
		<script src="themes/js/common.js"></script>
		
    </body>
</html>